<div class="se-pre-con"></div>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('css/jquery-confirm.css'); ?>"> 
<script type="text/javascript" src="<?php echo base_url('js/jquery-confirm.js')?>"></script><!--jquery-->
<style type="text/css">

    .affix-top {
      position: relative;
    }

    .affix {
      top: 70px;
    }

    .affix, 
    .affix-bottom {
        width: 168px;
    }

    .affix-bottom {
      position: absolute;
    }
    
/*    table{
        margin: 0 auto;
        width: 100%;
        clear: both;
        border-collapse: collapse;
        table-layout: fixed;
        word-wrap:break-word;
      }*/

</style>
<div class="row">
    <div class="col-md-12">
        <h3 class="page-header"><i class="fa fa-users"></i> STUDENT REPORT VIEW</h3>
        <ol class="breadcrumb">
            <li><i class="fa fa-home"></i><a href="<?php echo base_url('dashboard')?>">Home</a></li>
            <li><i class="fa fa-cog"></i>Report</li>
            <li><i class="fa fa-bank"></i>Student List View</li>
        </ol>
    </div>
</div>
<div class="tab-content">
    <div role="tabpanel" class="tab-pane active" id="lookup_tab">
        <div class="panel">
            <div class="panel-heading">
                Student Reports
            </div>
            <div class="panel-body">
                <div class="row">
                    <!-- ------------------ -->
                    <div class="col-md-12">
                        <div>
                            <ul class="nav nav-tabs" role="tablist">
                                <li role="presentation" class="active"><a class="fa fa-user" href="#full_summary_tab" aria-controls="full_summary_tab" role="tab" data-toggle="tab"> Full Summary</a></li>
                                <li role="presentation"><a class="fa fa-university" href="#center_wise_full_tab" aria-controls="center_wise_full_tab" role="tab" data-toggle="tab"> Center wise Full Summary</a></li>
                                <li role="presentation"><a class="fa fa-graduation-cap" href="#center_wise_detail_tab" aria-controls="center_wise_detail_tab" role="tab" data-toggle="tab"> Center wise Detail Summary</a></li>
                            </ul>
                            <div class="tab-content">
                                <div role="tabpanel" class="tab-pane active" id="full_summary_tab"><br/>
                                    <!--<form class="form-horizontal" role="form" method="post"  id="full_sum_form" action="<?php echo base_url('report/student_list_full_summary_pdf') ?>"  autocomplete="on" novalidate enctype="multipart/form-data">-->
                                    <div class="row">
                                        <div class="col-md-12">
<!--                                            <button type="submit" style="float: right; margin-right: 5%;" class="btn btn-success">Print Report</button>-->
                                            <button style="float: right; margin-right: 1.5%;" class="btn btn-success" id="print_full" name="print_full" onclick="window.open('<?php echo base_url("report/student_list_full_summary_pdf") ?>');">Print Report</button>
                                        </div>
                                    </div>
                                    
                                    <table id="full_sum" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Center</th>
                                                <th>Center Code</th>
                                                <th>Course</th>
                                                <th>Course Code</th>
                                                <th>Total Students</th>
                                                <th>Approve</th>
                                                <th>Not Approve</th>
                                                <th>Reject</th>
                                            </tr>
                                        </thead>
                                        <tbody id="tbl_body">
                                            <?php
                                            $i = 1;
                                            $total_student = 0;
                                            $total_approved = 0;
                                            $total_reject = 0;
                                            $total_not_approve = 0;
                                            
                                            $center_total_student = 0;
                                            $center_total_approved = 0;
                                            $center_total_reject = 0;
                                            $center_total_not_approve = 0;
                                            
                                            
                                            if (!empty($stu_all_count_array)) 
                                            {
                                                //foreach ($stu_all_count_array as $va) 
                                                for($k=0; $k < count($stu_all_count_array);$k++)
                                                {
                                                    $va = $stu_all_count_array[$k];
                                                    
                                                    if($k == 0)
                                                    {

                                                        echo '<tr>'.
                                                            '<td>'.$va['br_name'].'</td>'.
                                                            '<td>'.$va['br_code'].'</td>'.
                                                            '<td style="white-space: initial;">'.$va['course_name'].'</td>'.
                                                            '<td>'.$va['course_code'].'</td>'.
                                                            '<td align="center">'. $va['stu_count'].'</td>'.  
                                                            '<td align="center">'.$va['apprv_status'] .'</td>'.
                                                            '<td align="center">'.$va['status'].'</td>'. 
                                                            '<td align="center">'.$va['reject_status'].'</td>'. 
                                                        '</tr>';
                                                    }
                                                    else
                                                    {
                                                        if($stu_all_count_array[$k-1]['br_code'] != $stu_all_count_array[$k]['br_code'])
                                                        {
                                                            echo '<tr style="font-weight:bold;">'.

                                                                '<td style="border-right: 0;">'.$stu_all_count_array[$k-1]['br_name'].' ATI Total</td>'.
                                                                '<td style="border-right: 0;"></td>'.
                                                                '<td style="border-right: 0;"></td>'.
                                                                '<td></td>'.
                                                                '<td align="center">'.$center_total_student.'</td>'.
                                                                '<td align="center">'. $center_total_approved.'</td>'.
                                                                '<td align="center">'. $center_total_not_approve.'</td>'.
                                                                '<td align="center">'. $center_total_reject.'</td>'.
                                                            '</tr>';
                                                            
                                                            $center_total_student = 0;
                                                            $center_total_approved = 0;
                                                            $center_total_reject = 0;
                                                            $center_total_not_approve = 0;
                                                        }
                                                        echo '<tr>'.
                                                                    '<td>'.$va['br_name'].'</td>'.
                                                                    '<td>'.$va['br_code'].'</td>'.
                                                                    '<td style="white-space: initial;">'.$va['course_name'].'</td>'.
                                                                    '<td>'.$va['course_code'].'</td>'.
                                                                    '<td align="center">'. $va['stu_count'].'</td>'.  
                                                                    '<td align="center">'.$va['apprv_status'] .'</td>'.
                                                                    '<td align="center">'.$va['status'].'</td>'. 
                                                                    '<td align="center">'.$va['reject_status'].'</td>'. 
                                                                '</tr>';
                                                    }
                                                    $i++;
                                                    $center_total_student += $va['stu_count'];
                                                    $center_total_approved += $va['apprv_status'];
                                                    $center_total_reject += $va['reject_status'];
                                                    $center_total_not_approve += $va['status']; 
                                                    
                                                    $total_student += $va['stu_count'];
                                                    $total_approved += $va['apprv_status'];
                                                    $total_reject += $va['reject_status'];
                                                    $total_not_approve += $va['status']; 
                                                }
                                                echo '<tr style="font-weight:bold;">'.

                                                '<td style="font-weight:bold; border-right: 0;">'.$stu_all_count_array[$k-1]['br_name'].' ATI Total</td>'.
                                                '<td style="border-right: 0;"></td>'.
                                                '<td style="border-right: 0;"></td>'.
                                                '<td></td>'.
                                                '<td align="center">'.$center_total_student.'</td>'.
                                                '<td align="center">'. $center_total_approved.'</td>'.
                                                '<td align="center">'. $center_total_not_approve.'</td>'.
                                                '<td align="center">'. $center_total_reject.'</td>'.
                                            '</tr>';
                                            }
                                            
                                            ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Grand Total</th>
                                                <th></th>
                                                <th></th>
                                                <th></th>
                                                <th> <?php echo $total_student ?></th>
                                                <th> <?php echo $total_approved ?></th>
                                                <th> <?php echo $total_not_approve ?></th>
                                                <th> <?php echo $total_reject ?></th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                    <!--</form>-->
                                </div>
                                <div role="tabpanel" class="tab-pane" id="center_wise_full_tab"></br>
                                    <form class="form-horizontal" role="form" method="post" id="search_form" autocomplete="off">
                                    <div class="row">
                                        <div class="col-md-1"></div>
                                            <div class="col-md-11">
                                                <div class="form-group col-md-6">
                                                    <div class="form-group">
                                                        <label for="inputEmail3" class="col-md-3 control-label">Search Type:</label>
                                                        <div class="col-md-9">
                                                            <input type="radio" name="type" class="col-md-1" id="gender_type" value="gender" checked="checked" onchange="load_course_wise();">
                                                            <label class="col-md-5 control-label">Gender wise (Male/Female)</label>
                                                            
                                                            <input type="radio" name="type" class="col-md-1" id="time_type" value="time" onchange="load_course_wise();">
                                                            <label class="col-md-5 control-label">Time wise (Part time/Full time)</label>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <button style="float: right; margin-right: -109%;" class="btn btn-success" id="print_course_wise" name="print_course_wise" onclick="load_pdf_course_wise();">Print Report</button>
                                                        </div>
                                                    </div>				
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                    </br>
                                        <table id="center_full_sum" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Center</th>
                                                <th>Center Code</th>
                                                <th>Course</th>
                                                <th>Course Code</th>
                                                <th id="header1">Male</th>
                                                <th id="header2">Female</th>
                                                <th>Total Count</th>
                                            </tr>
                                        </thead>
                                        <tbody id="tbl_body">
                                            
                                        </tbody>
                                        <tfoot>
                                        <tr>
                                            <th>Grand Total</th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th>0</th>
                                            <th>0</th>
                                            <th>0</th>
                                        </tr>
                                     </tfoot>
                                    </table>
                                </div>
                               <div role="tabpanel" class="tab-pane" id="center_wise_detail_tab"><br>
                                    <form class="form-horizontal" role="form" method="post" id="search_form" autocomplete="off">
                                        <div class="row">
                                            <div class="col-md-1"></div>
                                            <div class="col-md-11">
                                                <div class="form-group col-md-4">
                                                    <div class="form-group">
                                                        <label for="center" class="col-md-3 control-label">Center : </label>
                                                        <div class="col-md-7">
                                                            <?php 
                                                        global $branchdrop;
                                                        global $selectedbr;

                                                        if(isset($stu_data))
                                                        {
                                                            $selectedbr = $stu_data['center_id'];
                                                        }

                                                        $extraattrs = 'id="center_id" class="form-control" style="width:100%" data-validation="required" data-validation-error-msg-required="Field can not be empty" onchange="load_course_list(this.value,null,this);"';

                                                        echo form_dropdown('center_id',$branchdrop,$selectedbr, $extraattrs);
                                                        ?>
                                                        </div>
                                                    </div>				
                                                </div>
                                                <div class="form-group col-md-4">							
                                                    <div class="form-group">
                                                        <label for="inputEmail3" class="col-md-3 control-label">Course Code:</label>
                                                        <div class="col-md-9">
                                                            <!--<select type="text" class="form-control" id="l_Dcode" name="l_Dcode" onchange="get_course_code(this.value, 1, null, null, 1)" required placeholder="field cannot be empty" data-validation="required" data-validation-error-msg-required="Field can not be empty" value="">-->
                                                            <select class="form-control" id="course_id" name="course_id" required placeholder="field cannot be empty" data-validation="required" data-validation-error-msg-required="Field can not be empty" value="" onchange="load_batch_list(this.value);">    
                                                                <option value="">---Select Course Code---</option>
                                                            </select>
                                                        </div>				         
                                                    </div>				
                                                </div>
                                                <div class="form-group col-md-4">							
                                                    <div class="form-group">
                                                        <label for="inputEmail3" class="col-md-3 control-label">Batch Code:</label>
                                                        <div class="col-md-9">
                                                            <select type="text" class="form-control" id="l_Bcode" name="l_Bcode" required placeholder="field cannot be empty" data-validation="required" data-validation-error-msg-required="Field can not be empty" value="" onchange="load_year_list();">
                                                                <option value="">---Select Batch Code---</option>			
                                                            </select>											
                                                        </div>				         
                                                    </div>				
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-1"></div>
                                            <div class="col-md-11">
                                                <div class="form-group col-md-4">
                                                    <div class="form-group">
                                                        <label for="inputEmail3" class="col-md-3 control-label">Year:</label>
                                                        <div class="col-md-9">

                                                            <select type="text" class="form-control" id="l_no_year" name="l_no_year" required placeholder="field cannot be empty" data-validation="required" data-validation-error-msg-required="Field can not be empty" value="" onchange="load_semesters(this.value);">
                                                                <option value="">---Select Year---</option>
                                                            </select>											
                                                        </div>				         
                                                    </div>				
                                                </div>
                                                <div class="form-group col-md-4">							
                                                    <div class="form-group">
                                                        <label for="inputEmail3" class="col-md-3 control-label">Semester:</label>
                                                        <div class="col-md-9">
                                                            <select type="text" class="form-control" id="l_no_semester" name="l_no_semester" required placeholder="field cannot be empty" data-validation="required" data-validation-error-msg-required="Field can not be empty" value="">
                                                                <option value="">---Select Semester---</option>	
                                                            </select>											
                                                        </div>				         
                                                    </div>				
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-10"></div>
                                            <div class="col-md-2">
                                                <button style="margin-left: -30px;" type="button" class="btn btn-primary btn-md" name="search" onclick="search_student_details();">Search</button>        
                                            
                                                <button type="button" style="float: right; margin-right: 12px;" id="print_btn" name="print_btn" class="btn btn-success" onclick="load_pdf_course_detail();">Print Report</button>
                                            </div>
                                        </div>
                                    </form>
                                    <!--<div class="panel-body">-->
                                        <div class="row">
                                            <div class="col-md-12">
                                                <table id="student_list" name="student_list" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%" cellspacing="0">
                                                    <thead>
                                                        <tr>
                                                            <th>Center</th>
                                                            <th>Register Number</th>
                                                            <th>Student Name</th>
                                                            <th>NIC No</th>
                                                            <th>Course</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody id="tbl_body">
                                                        
                                                        <?php
//                                                            $i = 1;
//                                                            if (!empty($result_array)) {
//                                                            foreach ($result_array as $va) {
                                                        ?>

<!--                                                        <tr>
                                                            <td align="center"> <?php //echo $i ?></td>
                                                            <td> <?php //echo $va['reg_no'] ?></td>
                                                            <td> <?php //echo $va['first_name'] . " " . $va['last_name'] ?></td>
                                                            <td> <?php //echo $va['nic_no'] ?></td>
                                                            <td align="center">
                                                                <a class="btn btn-default btn-xs" onclick="event.preventDefault();stueditview('<?php //echo $va['stu_id'] ?>')"><span class="glyphicon glyphicon-folder-open" aria-hidden="true"></span></a> | 
                                                                <a class="btn btn-info btn-xs" onclick="event.preventDefault();load_stueditview('<?php //echo $va['stu_id'];?>')"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></a> | 

                                                                <?php //if ($va["deleted"] == "0") { ?>
                                                                    <button onclick="event.preventDefault();update_stu_status('<?php //print_r($va["stu_id"]) ?>', '1')" class='btn btn-warning btn-xs'><span class='glyphicon glyphicon-ban-circle' aria-hidden='true'></span></button>
                                                                <?php //} else { ?>
                                                                    <button onclick="event.preventDefault();update_stu_status('<?php //print_r($va["stu_id"]) ?>', '0')" class='btn btn-success btn-xs'><span class='glyphicon glyphicon-ok-circle' aria-hidden='true'></span></button>
                                                                <?php //} ?>
                                                            </td>
                                                        </tr>-->
                                                        <?php
                                                               // $i++;
                                                          //  }
                                                      //  }
                                                        ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    <!--</div>-->
                                </div>
                            </div>
                        </div>
                    </div>
                <!-- ------------------- -->
                </div>
            </div>
        </div>
    </div>
</div>            

<script type="text/javascript">
   
    $.validate({
        form: '#stu_reg'
    });

    $(document).ready(function () {
        
        var rowCount = $('#full_sum tbody tr').length;
        if(rowCount > 0){
           $('#print_full').attr('disabled', false);
        }
        else{
           $('#print_full').attr('disabled', true); 
        }
        
        
        $('#print_btn').attr('disabled', true);
        $('#print_course_wise').attr('disabled', true);
        
        $('#student_list').DataTable({
            'ordering': true,
            'lengthMenu': [10, 25, 50, 75, 100]
        });

        if($('#user_level').val() == "1"){
            $('#center_id').find('option').get(0).remove();
            $("#center_id").prepend($("<option selected='selected'></option>").attr("value", "all").text("All"));
        }
        
        load_course_list($("#center_id").val());
        
        load_batch_list($("#center_id").val());
        
        $('#full_sum').DataTable({
            'ordering': true,
            'lengthMenu': [10, 25, 50, 75, 100],
            'paging': false
            //'scrollX':true
        });
        
        $('#center_full_sum').DataTable({
            'ordering': true,
            'lengthMenu': [10, 25, 50, 75, 100],
            'paging': false
        });
        
        $('#mahapola').DataTable({
            'ordering': true,
            'lengthMenu': [10, 25, 50, 75, 100],
            'paging': false
        });
        
        load_course_wise();
      
    });
    
    function load_course_wise(){
        
        var type_val;
        
        if($('input[name=type]:checked')){
            type_val = $('input[name=type]:checked').val();
        }
        
        if(type_val == "gender"){
            $('#header1').text("Male");
            $('#header2').text("Female");
        }
        if(type_val == "time"){
            $('#header1').text("Part Time");
            $('#header2').text("Full Time");
        }
    
        $.post("<?php echo base_url('Report/student_course_wise_details')?>",{'type_val':type_val},
            function(data)
            {
                console.log(data);
                $('#center_full_sum').DataTable().destroy();
                

                $('#center_full_sum').DataTable({
                    'ordering': true,
                    'paging': false,
                    "columnDefs": [ {
                        "targets": 4,
                        "className": "text-center"
                    },
                    {
                        "targets": 5,
                        "className": "text-center"
                    },
                    {
                        "targets": 6,
                        "className": "text-center"
                    }],
                    'footerCallback': function ( row, data, start, end, display ) {
                 
                        var api = this.api(), data;

                        // Remove the formatting to get integer data for summation
                        var intVal = function ( i ) {
                            return typeof i === 'string' ?
                                i.replace(/[\$,]/g, '')*1 :
                                typeof i === 'number' ?
                                    i : 0;
                        };

                        // Total over all pages
                        total_5 = api
                            .column(4)
                            .data()
                            .reduce(function (a, b) {
                                return intVal(a) + intVal(b);
                        }, 0);

                        total_6 = api
                            .column(5)
                            .data()
                            .reduce(function (a, b) {
                                return intVal(a) + intVal(b);
                        }, 0);
                        
                        total_7 = api
                            .column(6)
                            .data()
                            .reduce(function (a, b) {
                                return intVal(a) + intVal(b);
                        }, 0);

                        // Total over this page
//                        pageTotal = api
//                            .column(5, {page: 'current'})
//                            .data()
//                            .reduce(function (a, b) {
//                                return intVal(a) + intVal(b);
//                        }, 0);

                        // Update footer
                        $( api.column(0).footer()).html(
                            'Grand Total'
                        );

                        $( api.column(4).footer()).html(
                            total_5
                        );

                        $( api.column(5).footer()).html(
                            total_6
                        );
                
                        $( api.column(6).footer()).html(
                            total_7
                        );
                

                    }
                });
                
                $('#center_full_sum').DataTable().clear();
                
                var r = 1;
                if(data.length > 0)
                {
                    $('#print_course_wise').attr('disabled', false);
                    
                    for (x = 0; x < data.length; x++) {

                        $('#center_full_sum').DataTable().row.add([
                            data[x]['br_name'],
                            data[x]['br_code'],
                            data[x]['course_name'],
                            data[x]['course_code'],
                            data[x]['type1'],
                            data[x]['type2'],
                            data[x]['type3']
                        ]).draw(false);

                        r++;
                    }
                }
                else{
                    $('#print_course_wise').attr('disabled', true);
                }
            },  
            "json"
            );
    }


    function update_stu_status(student_id, new_status)
    {
        var batch_id = $('#l_Bcode').val();
        $.ajax(
                {
                    url: "<?php echo base_url('student/change_student_status') ?>",
                    type: 'POST',
                    async: true,
                    cache: false,
                    dataType: 'json',
                    data: {'student_id': student_id, 'new_status': new_status},
                    success: function (data)
                    {
                        if (data == 'denied')
                        {
                            funcres = {status: "denied", message: "You have no right to proceed the action"};
                            result_notification(funcres);
                        } else
                        {
                            if (batch_id == '' || batch_id == 0 || batch_id == null) {
                                location.reload();
                            } else {
                                search_details();
                            }

                            result_notification(data);
                        }
                    }
                });

    }

    

    /*
    * load courses
    */
    function load_course_list(center_id)
    {
        $('#course_id').find('option').remove().end();
        $("#course_id").prepend($("<option selected='selected'></option>").attr("value", "all").text("All"));
        //$('#course_id').append('<option value="">---Select Course Code---</option>').val('');

        $.post("<?php echo base_url('Report/load_course_list') ?>", {'center_id': center_id},

        function (data)
        {
            for (var i = 0; i < data.length; i++) 
            {
                $('#course_id').append($("<option></option>").attr("value", data[i]['course_id']).text(data[i]['course_code']+' - '+data[i]['course_name']));
            }
            
            //load_batch_list($('#course_id').val());
        },
        "json"
        );
    }


    /*
    * load years
    */
    function load_year_list()
    {
        if(($('#course_id').val())!= "0"){
            var cou_id = $('#course_id').val();

            $.post("<?php echo base_url('Report/load_year_list') ?>",{'selected_course_id': cou_id},

            function (data)
            { 
                var year = data['no_of_year'];
                var id = data['id'];
                
                //console.log(year+"-"+id);

                $('#l_no_year').find('option').remove().end();
                $('#l_no_year').prepend($("<option selected='selected'></option>").attr("value", "all").text("All"));

                    for (var i=1; i <= year; i++) 
                    {
                        $('#l_no_year').append($("<option></option>").attr("value", i+'-'+id).text(i + " Year"));
                    }
                    
                    load_semesters($('#l_no_year').val());
            },
            "json"
            );
        }
    }

    /*
    * load batches
    */
    function load_batch_list(selected_course_id)
    {
        $.post("<?php echo base_url('Report/load_batch_list') ?>",{'selected_course_id': selected_course_id},

        function (data)
        {
            $('#l_Bcode').find('option').remove().end();
            $('#l_Bcode').prepend($("<option selected='selected'>---No Batch Filter---</option>").attr("value", ""));
           
                for (var i = 0; i < data.length; i++) 
                {
                    if((data[i]['batch_code'].length) != 0)
                    {
                        $('#l_Bcode').append($("<option></option>").attr("value", data[i]['id']).text(data[i]['batch_code']));
                    }
                }

                load_year_list();
        },
        "json"
        );
    }


    function load_semesters(year_no) 
    {
        var sel_year = "";
        var sel_year_id = "";
        
        if(year_no != "all"){
           sel_year = year_no.split('-')[0].trim();
           sel_year_id = year_no.split('-')[1].trim(); 
        }
        

        $.post("<?php echo base_url('Report/load_semesters') ?>", {'year_id': sel_year_id, 'year_no': sel_year},

        function (data)
        {
            $('#l_no_semester').find('option').remove().end();
            $("#l_no_semester").prepend($("<option selected='selected'></option>").attr("value", "all").text("All"));
            //$('#l_no_semester').append('<option value="">---Select Semester---</option>').val('');

            for (var i=1; i <= data; i++) 
            {
                $('#l_no_semester').append($("<option></option>").attr("value", i).text(i + " Semester"));

            }
        },
        "json"
        );
    }


    function search_student_details()
    {
        $('.se-pre-con').fadeIn('slow');
        
        var center_id   = $('#center_id').val();
        var course_id   = $('#course_id').val();
        var year_no     = $('#l_no_year').val().split('-')[0].trim();
        var semester_no = $('#l_no_semester').val();
        var batch_id    = $('#l_Bcode').val();

        $.post("<?php echo base_url('Report/search_students_lookup') ?>", {'center_id': center_id, 'course_id': course_id, 'year_no': year_no, 'semester_no': semester_no, 'batch_id': batch_id},
            function (data)
            {
                console.log(data);
                if(data == 'denied')
                {
                    funcres = {status:"denied", message:"You have no right to proceed the action"};
                    result_notification(funcres);
                }
                else
                {
                    $('#student_list').DataTable().destroy();
                    $('#student_list').DataTable().clear().draw();
                        
                    if (data.length > 0) 
                    {
                        $('#print_btn').attr('disabled', false);
                        
                        for (j = 0; j < data.length; j++) {

                            number_content = "<td align='center'>" + (j + 1) + "</td>";

                            
                            $('#student_list').DataTable().row.add([
                                "[" + data[j]['br_code'] + "] - " + data[j]['br_name'],
                                data[j]['reg_no'],
                                data[j]['first_name'], //+ " " + data[j]['last_name'],
                                data[j]['nic_no'],
                                "[" + data[j]['course_code'] + "] - " + data[j]['course_name']
                            ]).draw(false);
                        }
                    }
                    else{
                        $('#print_btn').attr('disabled', true);
                    }
                }
                $('.se-pre-con').fadeOut('slow');
            },
            "json"
            );


    }
    
    
    function load_pdf_course_wise(){
        
        var type_val2;
        
        if($('input[name=type]:checked')){
            type_val2 = $('input[name=type]:checked').val();
        }
        
        window.open('<?php echo base_url("report/course_wise_full_summary_pdf") ?>?search_type=' + type_val2);
    }
    
    function load_pdf_course_detail(){
        
        var center_id = $('#center_id').val();
        var course_id = $('#course_id').val();
        var year_no = $('#l_no_year').val().split('-')[0].trim();
        var semester_no = $('#l_no_semester').val();
        var batch_id = $('#l_Bcode').val();

        window.open('<?php echo base_url("report/course_detail_summary_pdf") ?>?cen=' + center_id +'&cou=' +course_id+'&yr=' +year_no+'&sem=' +semester_no+'&bat=' +batch_id);
  
    }
    
    

</script>
